<?php
namespace GLGFRULES;

#   _____                       _____            __ _     _____  ______ 
#  / ____|                     / ____|          / _| |   |  __ \|  ____|
# | |  __  __ _ _ __ ___   ___| |     _ __ __ _| |_| |_  | |__) | |__   
# | | |_ |/ _` | '_ ` _ \ / _ \ |    | '__/ _` |  _| __| |  ___/|  __|  
# | |__| | (_| | | | | | |  __/ |____| | | (_| | | | |_  | |    | |____ 
#  \_____|\__,_|_| |_| |_|\___|\_____|_|  \__,_|_|  \__| |_|    |______|

use pocketmine\utils\TextFormat;
use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\Player;

class Main extends PluginBase implements Listener{
	public function onEnable(){
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->saveDefaultConfig();
		$this->getLogger()->info(TEXTFORMAT::GOLD . "[--GLGF Rules--]" .TEXTFORMAT::RED. " --> -->" .TEXTFORMAT::AQUA.  " Hurahh! GLGF Rules is Active on Version ".$this->getDescription()->getVersion());
    }
	public function onCommand(CommandSender $sender, Command $command, $label, array $args) {
        $cmd = strtolower($command->getName());
        switch ($cmd){
            case "rules":
                if (!($sender instanceof Player)){
                    $sender->sendMessage(TEXTFORMAT::GOLD . "--------[GLGF Rules]--------");
                    $sender->sendMessage(TEXTFORMAT::GREEN . "- " . $this->getConfig()->get("rules1"));
                    $sender->sendMessage(TEXTFORMAT::GREEN . "- " . $this->getConfig()->get("rules2"));
                    $sender->sendMessage(TEXTFORMAT::GREEN . "- " . $this->getConfig()->get("rules3"));
                    $sender->sendMessage(TEXTFORMAT::GREEN . "- " . $this->getConfig()->get("rules4"));
                    $sender->sendMessage(TEXTFORMAT::GREEN . "- " . $this->getConfig()->get("rules5"));
                    $sender->sendMessage(TEXTFORMAT::GREEN . "- " . $this->getConfig()->get("rules6"));
                    $sender->sendMessage(TEXTFORMAT::GREEN . "- " . $this->getConfig()->get("rules7"));
                    $sender->sendMessage(TEXTFORMAT::GREEN . "- " . $this->getConfig()->get("rules8"));
                    return true;
                }
                $player = $this->getServer()->getPlayer($sender->getName());
                if ($player->hasPermission("glgf.rules")){
                    $sender->sendMessage("§a--------§2[GLGF Rules]§a--------");
                    $sender->sendMessage("§2- " . $this->getConfig()->get("rules1"));
                    $sender->sendMessage("§a- " . $this->getConfig()->get("rules2"));
                    $sender->sendMessage("§a- " . $this->getConfig()->get("rules3"));
                    $sender->sendMessage("§2- " . $this->getConfig()->get("rules5"));
                    $sender->sendMessage("§2- " . $this->getConfig()->get("rules6"));
                    $sender->sendMessage("§a- " . $this->getConfig()->get("rules7"));
                    $sender->sendMessage("§2- " . $this->getConfig()->get("rules8"));
                    $sender->sendMessage("§a- " . $this->getConfig()->get("rules9"));
                    $sender->sendMessage("§2- " . $this->getConfig()->get("rules10"));
                    return true;
                }
                break;
            }
        }
    }
?>