<?php
namespace GLGFInfo;

#   _____                       _____            __ _     _____  ______ 
#  / ____|                     / ____|          / _| |   |  __ \|  ____|
# | |  __  __ _ _ __ ___   ___| |     _ __ __ _| |_| |_  | |__) | |__   
# | | |_ |/ _` | '_ ` _ \ / _ \ |    | '__/ _` |  _| __| |  ___/|  __|  
# | |__| | (_| | | | | | |  __/ |____| | | (_| | | | |_  | |    | |____ 
#  \_____|\__,_|_| |_| |_|\___|\_____|_|  \__,_|_|  \__| |_|    |______|

use pocketmine\utils\TextFormat;
use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\Player;

class Main extends PluginBase implements Listener{
	public function onEnable(){
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->saveDefaultConfig();
		$this->getLogger()->info(TEXTFORMAT::GOLD . "[--GLGFInfo--]" .TEXTFORMAT::RED. " --> -->" .TEXTFORMAT::AQUA.  " Hurahh! GLGFInfo is Active on Version ".$this->getDescription()->getVersion());
    }
	public function onCommand(CommandSender $sender, Command $command, $label, array $args) {
        $cmd = strtolower($command->getName());
        switch ($cmd){
            case "staff":
                if (!($sender instanceof Player)){
                    $sender->sendMessage(TEXTFORMAT::GOLD . "--------[GLGFInfo]--------");
                    $sender->sendMessage(TEXTFORMAT::GREEN . "- " . $this->getConfig()->get("info1"));
                    $sender->sendMessage(TEXTFORMAT::GREEN . "- " . $this->getConfig()->get("info2"));
                    $sender->sendMessage(TEXTFORMAT::GREEN . "- " . $this->getConfig()->get("info3"));
                    $sender->sendMessage(TEXTFORMAT::GREEN . "- " . $this->getConfig()->get("info4"));
                    $sender->sendMessage(TEXTFORMAT::GREEN . "- " . $this->getConfig()->get("info5"));
                    $sender->sendMessage(TEXTFORMAT::GREEN . "- " . $this->getConfig()->get("info6"));
                    $sender->sendMessage(TEXTFORMAT::GREEN . "- " . $this->getConfig()->get("info7"));
                    $sender->sendMessage(TEXTFORMAT::GREEN . "- " . $this->getConfig()->get("info8"));
                    $sender->sendMessage(TEXTFORMAT::GREEN . "- " . $this->getConfig()->get("info9"));
                    return true;
                }
                $player = $this->getServer()->getPlayer($sender->getName());
                if ($player->hasPermission("glgf.info")){
                    $sender->sendMessage("§a--------§2[GLGFInfo]§a--------");
                    $sender->sendMessage("§2- " . $this->getConfig()->get("info1"));
                    $sender->sendMessage("§a- " . $this->getConfig()->get("info2"));
                    $sender->sendMessage("§a- " . $this->getConfig()->get("info3"));
                    $sender->sendMessage("§2- " . $this->getConfig()->get("info4"));
                    $sender->sendMessage("§2- " . $this->getConfig()->get("info5"));
                    $sender->sendMessage("§a- " . $this->getConfig()->get("info6"));
                    $sender->sendMessage("§2- " . $this->getConfig()->get("info7"));
                    $sender->sendMessage("§a- " . $this->getConfig()->get("info8"));
                    $sender->sendMessage("§2- " . $this->getConfig()->get("info9"));
                    return true;
                }
                break;
            }
        }
    }
?>