<?php
namespace Kagiamy\GLGFAuth;

use pocketmine\Player;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\plugin\PluginBase;
use pocketmine\Server;
use pocketmine\event\Listener;
use pocketmine\plugin\Plugin;
use pocketmine\utils\TextFormat as Color;
use pocketmine\utils\config;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;

class Main extends PluginBase implements Listener{
    
    protected $authed_users = [];

        public function isAuthed($player){
        if($player instanceof Player){
            $player = $player->getName();
        }
        return isset($this->authed_users[$player]);
    }
    
    public function authPlayer(Player $player){
        $this->authed_users[$player->getName()] = true;
        $player->sendMessage(Color::GREEN . 'You have been authenticated(•§eBạn Đã Đăng Nhập).');
    }
    
    /**
     * @priority HIGHEST
     */
    public function onQuit(PlayerQuitEvent $event){
        $name = $event->getPlayer()->getName();
        if($this->isAuthed($name)){
            unset($this->authed_users[$name]);
        }
    }
    
    /**
     * @priority HIGHEST
     */
    public function onMove(PlayerMoveEvent $event){
        $name = $event->getPlayer()->getName();
        if(!$this->isAuthed($name)){
            $event->setCancelled();
        }
    }
        /**
     * @priority HIGHEST
     */
    public function onBreak(BlockBreakEvent $event){
        $name = $event->getPlayer()->getName();
        if(!$this->isAuthed($name)){
            $event->setCancelled();
        }
    }
        public function onChat(PlayerChatEvent $event){
          $name = $event->getPlayer()->getName();
          $data = new Config($this->getDataFolder() . "/players/" . $name . ".yml", Config::YAML);
          $pass = $event->getMessage();
          $hash = $data->get($name);
          $player = $event->getPlayer();
          $password = password_verify($pass, $hash);
          $realpass = $data->get($name);
          $register = new Config($this->getDataFolder() . "/register.yml", Config::YAML);
          $registered = $register->get($name);
          if(!$this->isAuthed($name)){
            $event->setCancelled(true);
            if($password == $realpass){
              $this->authPlayer($event->getPlayer());
              $event->setCancelled();
            }
            if($registered == false){
                $ip = $player->getAddress();
                $time = date('l jS \of F Y h:i:s A');
                $name = $player->getName();
                $data = new Config($this->getDataFolder() . "/players/" . $name . ".yml", Config::YAML);
                $pass = $event->getMessage();
                $password =  password_hash($pass, PASSWORD_DEFAULT);
                $data->set($name,$password);
                $data->set($name . "-IP",$ip);
                $data->set("Registered-At",$time);
                $data->save();
                $register->set($name,true);
                $register->save();
                $this->authPlayer($player);
                $player->sendMessage("§b- You have sucussfully registered!(•§eBạn Đã Đăng Ký)");
            }
          }
      }

    public function onPlace(BlockPlaceEvent $event){
        $name = $event->getPlayer()->getName();
        if(!$this->isAuthed($name)){
            $event->setCancelled();
        }
    }
    public function onLoad(){
        @mkdir($this->getDataFolder());
    }

    public function onEnable(){
      date_default_timezone_set('EST');
      $this->getServer()->getPluginManager()->registerEvents($this ,$this);
      $config = new Config($this->getDataFolder() . "/config.yml", Config::YAML);
      $config->save();
      if($config->get("Join-Mesage1") == null){
          $config->set("JoinMessage1","&a- Chào Mừng Đến §dGLGF §cPVP");
          $config->save();
      }
      $this->getLogger()->info(Color::GREEN ."Enabled!");
    }

    public function onJoin(PlayerJoinEvent $event){
      $player = $event->getPlayer();
      $name = $player->getName();
      mkdir($this->getDataFolder() . "/players/", 0777,true);
      $register = new Config($this->getDataFolder() . "/register.yml", Config::YAML);
      $registered = $register->get($player->getName());
      $config = new Config($this->getDataFolder() . "/config.yml", Config::YAML);
      $message = $config->get("JoinMessage");
      $msg = str_replace("&","§",$message);
      $player->sendMessage($msg);
      $player->sendMessage("§o§7- Bạn Cần login/register để chơi!");
      if($registered == null){
        $register->set($player->getName(),false);
        $register->save();
        $player->sendMessage("§c- Đăng Ký Bằng Lệnh /register <Mật Khẩu> hoặc gõ mật khẩu của bạn trong chat!");
      }
      if($registered == true){
        $player->sendMessage("§e- Đăng Nhập Bằng Lệnh /login <Mật Khấu> hoặc gõ mật khẩu của bạn trong chat!");
      }
    }

    public function onCommand(CommandSender $sender, Command $cmd, $label, array $args){
      $register = new Config($this->getDataFolder() . "/register.yml", Config::YAML);
      $registered = $register->get($sender->getName());
        if($cmd->getName() == "login" && $registered == true){
          $time = date('l jS \of F Y h:i:s A');  
          $name = $sender->getName();
          $data = new Config($this->getDataFolder() . "/players/" . $name . ".yml", Config::YAML);
          $pass = $args[0];
          $hash = $data->get($name);
          $data->set("LastLogin",$time);
          $data->save();
          $password = password_verify($pass, $hash);
          $realpass = $data->get($name);
          if($password == $realpass){
            $this->authPlayer($sender);
        }
        else{
          $sender->sendMessage("§c- Mật khẩu không đúng!");
        }
      }
      if($cmd->getName() == "logout" && $registered == true){
        $name = $sender->getName();
        unset($this->authed_users[$name]);
        $sender->sendMessage("§a- Bạn Đã Logout!");
      }
      if($cmd->getName() == "register" && $registered == false) {
                $ip = $sender->getAddress();
                $time = date('l jS \of F Y h:i:s A');
                $email = $args[1];
                $name = $sender->getName();
                $data = new Config($this->getDataFolder() . "/players/" . $name . ".yml", Config::YAML);
                $pass = $args[0];
                $password =  password_hash($pass, PASSWORD_DEFAULT);
                $data->set($name,$password);
                $data->set($name . "-IP",$ip);
                $data->set("Registered-At",$time);
                $data->save();
                $register->set($name,true);
                $register->save();
                $this->authPlayer($sender);
                $sender->sendMessage("§b- You have sucussfully registered!(•§eBạn Đã Đăng Ký)!");
        }
        }
}