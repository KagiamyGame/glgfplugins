<?php
namespace ServerHub;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\player\PlayerItemHeldEvent;
use pocketmine\event\player\PlayerItemConsumeEvent;
use pocketmine\item\Item;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\Player;
use pocketmine\utils\TextFormat as Color;
use pocketmine\entity\Effect;
use pocketmine\block\Cake;
use pocketmine\block\Block;
use pocketmine\item\MagmaCream;
use pocketmine\event\player\PlayerJoinEvent;
class main extends PluginBase implements Listener{
	public $starting = array();
	public function onEnable(){
		$this->getLogger()->info(Color::RED . "BETA ENABLED!");
		$this->getServer()->getPluginManager()->registerEvents($this ,$this);
	}

	
	public function onCommand(CommandSender $sender, Command $cmd, $label, array $args){
        if($cmd->getName() == "hub"){
                    $spawn = $this->getServer()->getDefaultLevel(); 
                    $this->getServer()->getDefaultLevel()->loadChunk($spawn->getFloorX(), 
                    $spawn->getFloorZ()); $sender->teleport($spawn,0,0);
		    $sender->sendMessage(Color::DARK_RED."[ServerHub]".Color::RED." You Teleported to the Hub!");	
        }
        if($cmd->getName() == "stuck"){
		    $spawn = $sender->getLevel()->getSpawnLocation();
                    $sender->teleport($spawn);
        }
				    }
}
